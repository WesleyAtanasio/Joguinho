const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

const PORT = process.env.PORT || 3000;

let rooms = {};

io.on('connection', (socket) => {
    console.log('Novo jogador conectado:', socket.id);

    socket.on('createRoom', ({ picavara, vacalo, name }) => {
        console.log('Recebido createRoom:', { picavara, vacalo, name });
        if (!picavara || !vacalo || !name) {
            socket.emit('error', 'Dados inválidos para criar a sala');
            return;
        }
        const roomId = Math.random().toString(36).substring(2, 8);
        rooms[roomId] = { 
            host: socket.id, 
            players: [{ id: socket.id, name, picavara, vacalo }], 
            hostChoices: { picavara, vacalo } 
        };
        socket.join(roomId);
        socket.roomId = roomId; // Armazena o roomId no socket
        socket.emit('roomCreated', roomId);
        console.log(`Sala criada: ${roomId} pelo host ${name} (${socket.id}) com ${picavara} e ${vacalo}`);
    });

    socket.on('checkRoom', (roomId) => {
        if (rooms[roomId]) {
            socket.emit('roomAvailable', rooms[roomId]);
        } else {
            socket.emit('error', 'Sala não encontrada');
        }
    });

    socket.on('joinRoom', ({ roomId, name, picavara, vacalo }) => {
        if (rooms[roomId]) {
            if (rooms[roomId].players.length >= 2) {
                socket.emit('error', 'Sala cheia! Máximo de 2 jogadores.');
                return;
            }
            rooms[roomId].players.push({ id: socket.id, name, picavara, vacalo });
            socket.join(roomId);
            socket.roomId = roomId;
            io.to(roomId).emit('playerJoined', socket.id);
            socket.emit('joinedRoom', roomId);
            console.log(`${name} (${socket.id}) entrou na sala ${roomId} com ${picavara} e ${vacalo}`);
        } else {
            socket.emit('error', 'Sala não encontrada');
        }
    });

    socket.on('getRoomInfo', (roomId) => {
        if (rooms[roomId]) {
            socket.emit('roomInfo', rooms[roomId]);
        } else {
            socket.emit('error', 'Sala não encontrada');
        }
    });

    socket.on('disconnect', () => {
        console.log('Jogador desconectado:', socket.id);
        const roomId = socket.roomId;
        if (roomId && rooms[roomId]) {
            rooms[roomId].players = rooms[roomId].players.filter(p => p.id !== socket.id);
            if (rooms[roomId].players.length === 0) {
                setTimeout(() => {
                    if (rooms[roomId] && rooms[roomId].players.length === 0) {
                        delete rooms[roomId];
                        console.log(`Sala ${roomId} foi excluída por falta de jogadores`);
                    }
                }, 5000); // 5 segundos de tolerância
            }
        }
    });
});

server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});